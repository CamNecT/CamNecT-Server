from .parser import LIST_URL, SourceError, parse_list

def collect_listing(client, max_pages=20):
    articles, seen_pages = {}, set()
    page, last_page, fields = 1, 1, None
    while page <= last_page:
        if page > max_pages:
            raise SourceError('Page limit reached; increase only after inspecting board size')
        html, _ = client.html(LIST_URL, fields)
        listing = parse_list(html)
        signature = tuple(sorted(listing['articles']))
        if signature in seen_pages:
            raise SourceError('Pagination repeated a page; refusing incomplete listing')
        seen_pages.add(signature)
        articles.update(listing['articles'])
        last_page = max(last_page, listing['pages'])
        fields = {**listing['fields'], 'page': str(page + 1)}
        page += 1
    return articles, len(seen_pages)
